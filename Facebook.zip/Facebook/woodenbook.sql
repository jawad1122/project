-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2019 at 09:01 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `woodenbook`
--

-- --------------------------------------------------------

--
-- Table structure for table `coverimage`
--

CREATE TABLE `coverimage` (
  `Id` int(10) NOT NULL,
  `User_Id` int(40) NOT NULL,
  `Cover_Image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coverimage`
--

INSERT INTO `coverimage` (`Id`, `User_Id`, `Cover_Image`) VALUES
(3, 3, 'Background.jpg'),
(4, 4, 'screenshot.png');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `Id` int(10) NOT NULL,
  `User_Id` int(10) NOT NULL,
  `Title` varchar(200) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Media` varchar(100) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`Id`, `User_Id`, `Title`, `Description`, `Media`, `Time`) VALUES
(4, 4, 'First Post', 'First Post First Post First PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst PostFirst Post', 'screenshot.png', '2019-04-15 18:28:20'),
(5, 3, 'This is Second Post', 'This is Second Post This is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second PostThis is Second Post', 'typesofwebsites.PNG', '2019-04-15 18:28:24'),
(6, 4, 'This is Third Post', 'This is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third PostThis is Third Post', 'ATT00062-730937.jpg', '2019-04-15 18:28:42'),
(7, 3, 'First Project', 'sddsa', 'Background.jpg', '2019-04-15 18:23:25');

-- --------------------------------------------------------

--
-- Table structure for table `profileimage`
--

CREATE TABLE `profileimage` (
  `Id` int(10) NOT NULL,
  `User_Id` int(10) NOT NULL,
  `Profile_Images` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profileimage`
--

INSERT INTO `profileimage` (`Id`, `User_Id`, `Profile_Images`) VALUES
(1, 3, 'WordPress Logo.jpg'),
(2, 4, 'Photo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(10) NOT NULL,
  `First_Name` varchar(15) NOT NULL,
  `Last_Name` varchar(15) NOT NULL,
  `Email_or_Phone` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Date_Of_Birth` date NOT NULL,
  `Gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `First_Name`, `Last_Name`, `Email_or_Phone`, `Password`, `Date_Of_Birth`, `Gender`) VALUES
(3, 'Muhammad', 'Nadir', 'nk775498@gmail.com', '1234', '2019-04-01', 'Male'),
(4, 'Jawad', 'Abbasi', 'jawadabbasi42@gmail.com', '1234', '2018-08-01', 'Male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coverimage`
--
ALTER TABLE `coverimage`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `profileimage`
--
ALTER TABLE `profileimage`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coverimage`
--
ALTER TABLE `coverimage`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `profileimage`
--
ALTER TABLE `profileimage`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
