<?php  
$connect = mysqli_connect("localhost", "root", "", "woodenbook");
$sql = "INSERT INTO userdata(First_Name,Last_Name,Email_or_Phone,Password,Date_Of_Birth,Gender) VALUES('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["emailorphone"]."', '".$_POST["pass"]."', '".$_POST["birthday"]."', '".$_POST["gender"]."')";  
if(mysqli_query($connect, $sql))  
{  
     echo 'Data Inserted';  
}  
 ?>