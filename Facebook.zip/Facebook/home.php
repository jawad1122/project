<?php include('dbconnection.php'); 
session_start();
if(isset($_SESSION['uemail'])){
  header('home.php');
}
else{
 header('location:./');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>HomePage</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid">
 <!--Header Start-->
	<div class="row" id="header">
		<div class="col-md-6">
		<br>
		<form method="post" class="form-inline">
			
			<input type="search" name="sea" class="form-control">			
			<a href="" class="btn btn-primary">Search</a>
		
			</form>
		</div>
		

         <div class="col-md-4 text-right"><br>
         	<a href="" class="btn btn-info">Home</a>
         	<a href="" class="btn btn-info">Message</a>
         	<a href="" class="btn btn-info">Notification</a>
         	<a href="profile.php" class="btn btn-info">Profile</a>
         </div>

				<div class="col-md-2 text-right">
				<br>
			<a href="logout.php" class="btn btn-danger">Logout</a>
		</div>

	</div>
	<!--Header End-->

  <!--Profile Start-->
	<div class="row">
		<div class="col-md-3">
			
		</div>
		<!--<div class="col-md-2" style="border: 1px solid;height: 700px">
		<div class="text-center">
			<img src="Facebookpics/Profile.png" class="img-fluid" style="height: 200px">
			<?php 
			$email=$_SESSION['uemail'];
                    $profile_query="Select *from register where Email_or_Phone='$email'";
      $profile_query_run=mysqli_query($con,$profile_query);
$row=mysqli_fetch_array($profile_query_run);

			 ?>
			<h6>Name:<?php echo $row['1'].' '.$row['2']; ?></h6>
			<h6>Email:<?php echo $row['3']; ?></h6>
			<h6>Gender:<?php echo $row['6']; ?></h6>
			<h6>Date Of Birth:<?php echo $row['5']; ?></h6>
			
			</div>

		</div>-->

		<div class="col-md-6">
 
       		<form method="post" enctype="multipart/form-data">
				<div class="form-group">
					<label>Title</label>
					<input type="text" name="title" class="form-control">
				</div>


				<div class="form-group">
					<label>Description</label><br>
					<textarea cols="84" rows="10" name="description" class="form-control"></textarea>
					
				</div>
                
                <div class="form-group">
					<label>Upload</label><br>
				<input type="file" name="img" class="form-control">
			</div>

			<div class="form-group">
			
              <input type="submit" name="upload" class="btn btn-success float-right" value="Post">
          </div>
			</form>
			<?php 
if(isset($_POST['upload'])){
	$query="Select *from register where Email_or_Phone='{$_SESSION['uemail']}'";
      $query_run=mysqli_query($con,$query);
        $fetch=mysqli_fetch_array($query_run);

$userid=$fetch['0'];
$title=$_POST['title'];
$description=$_POST['description'];
$img_name=$_FILES['img']['name'];
$img_type=$_FILES['img']['type'];
$img_size=$_FILES['img']['size'];
$img_tmp=$_FILES['img']['tmp_name'];
$file_path="Images/$img_name";
move_uploaded_file($img_tmp,$file_path);

 
$posts="Insert into posts(User_Id,Title,Description,Media)
Values('$userid','$title','$description','$img_name')";
$posts_run=mysqli_query($con,$posts);
if($posts_run){
echo "<script>alert('Post Successfully')</script>";
}
else{
echo "<script>alert('Post Not Successfully')</script>";
}
}
      ?>
		
<br>
<br>
<div class="row">
	<div class="col-md-12">
		<?php 
       $posts_query="Select *from posts ORDER BY Id DESC";
      $posts_query_run=mysqli_query($con,$posts_query);

      while($posts_fetch=mysqli_fetch_array($posts_query_run)){
         	
         	$fetchuserid=$posts_fetch['1'];
 $sql="Select *from register where id='$fetchuserid'";
 $sql_run=mysqli_query($con,$sql);
 $fetchdata=mysqli_fetch_array($sql_run);
 



 $sql1="Select *from profileimage where User_Id='$fetchuserid'";
 $sql_run1=mysqli_query($con,$sql1);
 $fetchdata1=mysqli_fetch_array($sql_run1);
      		?>
       
     

			<h3><img height="40" width="40" src="Images/Profileimg/<?php echo $fetchdata1['Profile_Images'] ?>"><?php echo $fetchdata['1'].' '.$fetchdata['2']; ?></h3>
			<p><?php echo $posts_fetch['5'] ?></p>
			<p><?php echo $posts_fetch['2']; ?></p>
			<img class="img-fluid" src="Images/<?php echo $posts_fetch['4']; ?> ">

			<?php  
echo "<br><br><br>";
		} ?>
	</div>
</div>
		
		</div>


	</div>
	<!--Profile End-->



	
</div>
</body>
</html>