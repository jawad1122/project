<?php include('dbconnection.php'); 
session_start();
if(isset($_SESSION['uemail'])){
  header('location:home.php');
}
else{
 
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Facebook</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid">
 <!--Header Start-->
	<div class="row" id="header">
		<div class="col-md-6">
			<h2 style="color: white;line-height: 70px">Facebook</h2>
		</div>
		<div class="col-md-6">
			<div class="row">
				<div class="col-md-4">
				<form method="post">
					<div class="form-group">
    <label for="exampleInputPassword1" id="name">Email Or Phone</label>
    <input type="text" class="form-control" name="emailorphone" id="exampleInputPassword1" placeholder="Email Or Phone" class="col" required>
  </div>
				</div>

				<div class="col-md-4">
			<div class="form-group">
    <label for="exampleInputPassword1" id="name">Password</label>
    <input type="password" class="form-control" name="pass" id="exampleInputPassword1" placeholder="Password" class="col" required>
    
  </div>
				</div>


				<div class="col-md-4">
			<div class="form-group">
    
    <button type="submit" name="login" class="btn btn-success"  id="loginbtn" style="background: green;position: relative;top: 30px">Sign In</button>
  </div>
  </form>
				</div>
			</div>
		</div>
	</div>
	<?php 
     if(isset($_POST['login'])){
       $email=$_POST['emailorphone'];
       $pass=$_POST['pass'];
      $login_query="Select *from register where Email_or_Phone='$email' AND Password='$pass'";
      $login_query_run=mysqli_query($con,$login_query);
      if($row=mysqli_num_rows($login_query_run)<1){
      	echo "<script>alert('Wrong Email or Password')</script>";
}
else{
	$_SESSION['uemail']=$email;
header('location:home.php');
}

     }
	?>
	 <!--Header End-->


	  <!--Content Start-->
	<div class="row">
		<div class="col-md-6">
			<br><br><br><img src="facebookpics/facebookimg.png" class="img-fluid" id="image">
			<a href="signup.php" class="btn btn-success" id="createbtn">Create An Account</a>
		</div>
		<div class="col-md-6" id="signupform">
		<div style="position: relative;top: 30px">
		<h4>Create a new account</h4>
		<p>It's free and always will be</p>
		</div>
		<form method="post">
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
    
    <label for="exampleInputEmail1" id="name">First Name</label>
    <input type="text" class="form-control" name="firstname" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="First Name" class="">
  </div>
			</div>

				<div class="col-md-6">
				<div class="form-group">
 
    <label for="exampleInputEmail1" id="name">Last Name</label>
    <input type="text" class="form-control" name="lastname" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Last Name" class="col">
  </div>
			</div>
		</div>
  
  <div class="form-group">
    <label for="exampleInputPassword1" id="name">Email Or Phone</label>
    <input type="text" class="form-control" name="emailorphone" id="exampleInputPassword1" placeholder="Email Or Phone" class="col">
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1" id="name">Password</label>
    <input type="password" class="form-control" name="pass" id="exampleInputPassword1" placeholder="Password" class="col">

  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1" id="name">Confirm Password</label>
    <input type="password" class="form-control" name="cpass" id="exampleInputPassword1" placeholder="Confirm Password" class="col">
  </div>
  
 
  
  <div class="form-group">
    <label for="exampleInputPassword1" id="name">Birthday</label>
    <input type="date" class="form-control" name="birthday" id="exampleInputPassword1" placeholder="Password" class="col">
  </div>
  
   <div class="form-group">
    <label for="exampleFormControlSelect1" id="name">Gender</label>
    <select class="form-control" name="gender" id="exampleFormControlSelect1" class="col">
      <option value="Male">Male</option>
      <option value="Female">Female</option>
      <option value="Other">Other</option>
    </select>
  </div>
  <button type="submit" name="register" class="btn btn-primary"  class="col" style="background: green">Sign Up</button>
 
</form>


		</div>
	</div>
	<br>
	 <!--Content End-->

	 <div class="row">
	<div class="col-md-12" id="footer">
		<footer style="color: white;text-align: center;font-size: 25px;">
			&copy;Copyright <?php echo date('Y'); ?> All Right Reserved Created By Nadir Khan,Jawad Abbasi
		</footer>
	</div>
</div>
</div>
</body>
</html>
<?php

if(isset($_POST['register'])){
$fname=$_POST['firstname'];
$lname=$_POST['lastname'];
$emailorphone=$_POST['emailorphone'];
$pass=$_POST['pass'];
$confirmpass=$_POST['cpass'];
$gender=$_POST['gender'];
$birthday=$_POST['birthday'];
if($pass==$confirmpass){
$register_query="Insert into register(First_Name,Last_Name,
Email_or_Phone,Password,Date_Of_Birth,Gender)
Values('$fname','$lname','$emailorphone','$pass','$birthday','$gender')";
$register_query_run=mysqli_query($con,$register_query);
if($register_query_run){
echo "<script>alert('Register Successfully')</script>";
}
else{
echo "<script>alert('Register Not Successfully')</script>";
}
}
else{
	echo "<script>alert('Password Not Match')</script>";
}

}
?>