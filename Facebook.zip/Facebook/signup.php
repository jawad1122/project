<!DOCTYPE html>
<html>
<head>
	<title>Facebook</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<style type="text/css">
	#header{
      height: 80px;
      background: #2B5299;
	}
	#footer{
      height: 80px;
      background: #2B5299;
	
	}

	#name{ 
		color: white;
	}
	#createbtn{
		display: none;
	}
	@media (min-width:0px) and (max-width: 576px){
		
	#image{
		display: none;
	}
    
	}
	
</style>
<body>
<div class="container-fluid">
 <!--Header Start-->
<div class="row">
	<div class="col-md-12" id="header">
	<br>
		<a href="./" class="btn btn-primary">Back To Home</a>
	</div>
</div>
	 <!--Header End-->


	  <!--Content Start-->
	<div class="row">
<div class="col-md-3">
	
</div>
		<div class="col-md-6" id="signupform">
		<div style="position: relative;top: 30px">
		<h4>Create a new account</h4>
		<p>It's free and always will be</p>
		</div>
		<form method="post">
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
    
    <label for="exampleInputEmail1" id="name">First Name</label>
    <input type="text" class="form-control" name="fullname" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="First Name" class="">
  </div>
			</div>

				<div class="col-md-6">
				<div class="form-group">
 
    <label for="exampleInputEmail1" id="name">Last Name</label>
    <input type="text" class="form-control" name="fullname" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Last Name" class="col">
  </div>
			</div>
		</div>
  
  <div class="form-group">
    <label for="exampleInputPassword1" id="name">Email Or Phone</label>
    <input type="text" class="form-control" name="emailphone" id="exampleInputPassword1" placeholder="Email Or Phone" class="col">
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1" id="name">Password</label>
    <input type="password" class="form-control" name="pass" id="exampleInputPassword1" placeholder="Password" class="col">
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1" id="name">Confirm Password</label>
    <input type="password" class="form-control" name="cpass" id="exampleInputPassword1" placeholder="Confirm Password" class="col">
  </div>
  
 
  
  <div class="form-group">
    <label for="exampleInputPassword1" id="name">Birthday</label>
    <input type="date" class="form-control" name="birthday" id="exampleInputPassword1" placeholder="Password" class="col">
  </div>
  
   <div class="form-group">
    <label for="exampleFormControlSelect1" id="name">Gender</label>
    <select class="form-control" name="gender" id="exampleFormControlSelect1" class="col">
      <option value="Male">Male</option>
      <option value="Female">Female</option>
      <option value="Other">Other</option>
    </select>
  </div>
  <button type="submit" name="register" class="btn btn-primary"  class="col" style="background: green">Sign Up</button>
 
</form>


		</div>
	</div>
	<br>
	 <!--Content End-->

	 <div class="row">
	<div class="col-md-12" id="footer">
		
	</div>
</div>
</div>
</body>
</html>