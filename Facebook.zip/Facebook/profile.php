<?php include('dbconnection.php'); 
session_start();
if(isset($_SESSION['uemail'])){
  header('home.php');
}
else{
 header('location:./');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

</head>
<style type="text/css">
	#uploadprofile{
		margin-left: 90px;
	}
</style>
<body>
<div class="container-fluid">
 <!--Header Start-->
	<div class="row" id="header">
		<div class="col-md-6">
		<br>
		<form method="post" class="form-inline">
			
			<input type="search" name="sea" class="form-control">			
			<a href="" class="btn btn-primary">Search</a>
		
			</form>
		</div>
		

         <div class="col-md-4 text-right"><br>
         	<a href="home.php" class="btn btn-info">Home</a>
         	<a href="" class="btn btn-info">Message</a>
         	<a href="" class="btn btn-info">Notification</a>
         	<a href="" class="btn btn-info">Profile</a>
         </div>

				<div class="col-md-2 text-right">
				<br>
			<a href="logout.php" class="btn btn-danger">Logout</a>
		</div>

	</div>
	<!--Header End-->


<div class="row">
	<div class="col-md-12">
		<?php 
      $query="Select *from register where Email_or_Phone='{$_SESSION['uemail']}'";
      $query_run=mysqli_query($con,$query);
        $fetch=mysqli_fetch_array($query_run);

      $userid=$fetch['0'];




       $query1="Select *from coverimage WHERE User_Id='$userid'";
      $run1=mysqli_query($con,$query1);

      $fetch1=mysqli_fetch_array($run1);
		?>
			
			<img class="img-fluid" src="Images/Coverimg/<?php echo $fetch1['2']; ?> ">
			
		
<button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
 Upload Cover Image
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" >Upload Cover Picture</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" enctype="multipart/form-data">
        	<div class="form-group">
        		<input type="file" name="img" class="form-control">
        	</div>

        	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
        		
        	<button type="submit" name="upload" class="btn btn-success">Save changes</button>
        
        </form>
        
      </div>
    </div>
  </div>
</div>
	</div>


</div>


<div class="row">
	<div class="col-md-3" style="">

  <?php 

          $query2="Select *from profileimage WHERE User_Id='$userid'";
      $run2=mysqli_query($con,$query2);

      $fetch2=mysqli_fetch_array($run2);
		?>
			
			<img class="img-thumbnail" style="margin-top: -190px;margin-left: 40px;" id="profileimg" src="Images/Profileimg/<?php echo $fetch2['2']; ?> ">
			

		<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1" id="uploadprofile">
 Upload Profile Image
</button>



<!-- Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Upload Profile Picture</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" enctype="multipart/form-data">
        	<div class="form-group">
        		<input type="file" name="profileimg" class="form-control">
        	</div>

        	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
        		
        	<button type="submit" name="uploadprofile" class="btn btn-success">Save changes</button>
        
        </form>
        
      </div>
    </div>
  </div>
</div>
	</div>
</div>

	
</div>
</body>
</html>
<?php 
//Upload Cover Image
if(isset($_POST['upload'])){
$img_name=$_FILES['img']['name'];
$img_type=$_FILES['img']['type'];
$img_size=$_FILES['img']['size'];
$img_tmp=$_FILES['img']['tmp_name'];
$file_path="Images/Coverimg/$img_name";
move_uploaded_file($img_tmp,$file_path);

 $upload_cover="Update coverimage SET Cover_Image='$img_name' WHERE User_Id='$userid'";


$upload_cover_run=mysqli_query($con,$upload_cover);
if($upload_cover_run){
header('location:profile.php');
}
else{
echo "<script>alert('Not Successfully')</script>";
}
}

//Upload Profile Image
else if(isset($_POST['uploadprofile'])){

$profile_img_name=$_FILES['profileimg']['name'];
$profile_img_type=$_FILES['profileimg']['type'];
$profile_img_size=$_FILES['profileimg']['size'];
$profile_img_tmp=$_FILES['profileimg']['tmp_name'];
$file_path="Images/Profileimg/$profile_img_name";
move_uploaded_file($profile_img_tmp,$file_path);

 $upload_profile="Update profileimage SET Profile_Images='$profile_img_name' WHERE User_Id='$userid'";


$upload_profile_run=mysqli_query($con,$upload_profile);
if($upload_profile_run){
header('location:profile.php');
}
else{
echo "<script>alert('Not Successfully')</script>";
}
}
?>